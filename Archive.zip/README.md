Neighborhood Map App
=====================

Ensure you have npm, yarn, node installed.

* install app

`yarn install`

* run app

`yarn start`

and go to http://127.0.0.1:8181